package org.example.Bo;

public interface MemberService extends SuperService {
    boolean Login(String Username ,String Password);
}
