package org.example.Bo;

public interface SuperService {
}
