package org.example.Bo;

public interface AdminService extends SuperService {
    boolean getData(String Id , String Password);
}
