package org.example.Dao;

import org.hibernate.Session;

public interface SuperRepository {
    void SetSession(Session session);
}
