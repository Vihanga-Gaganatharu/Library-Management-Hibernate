package org.example.Dao;

import org.example.Entity.Branch;

public interface BranchRepository extends CrudUtil<Branch>{
}
