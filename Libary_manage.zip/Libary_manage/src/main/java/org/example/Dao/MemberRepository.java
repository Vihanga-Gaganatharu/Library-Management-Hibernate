package org.example.Dao;

import org.example.Entity.Member;

public interface MemberRepository extends CrudUtil<Member>{
}
